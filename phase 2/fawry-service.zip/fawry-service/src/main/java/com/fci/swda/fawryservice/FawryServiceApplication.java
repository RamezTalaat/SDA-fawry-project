package com.fci.swda.fawryservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FawryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FawryServiceApplication.class, args);
	}

}
