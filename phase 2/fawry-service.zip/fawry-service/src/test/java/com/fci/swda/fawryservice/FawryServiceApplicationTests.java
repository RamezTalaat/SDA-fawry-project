package com.fci.swda.fawryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FawryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
