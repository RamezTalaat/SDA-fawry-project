package com.example.fawrywebApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FawrywebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FawrywebAppApplication.class, args);
	}

}
